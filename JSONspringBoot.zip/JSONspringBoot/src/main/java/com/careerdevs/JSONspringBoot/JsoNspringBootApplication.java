package com.careerdevs.JSONspringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsoNspringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsoNspringBootApplication.class, args);
	}

}
