package com.careerdevs.JSONspringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsoNspringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
